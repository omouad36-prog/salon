import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LockKey, WarningCircle } from 'phosphor-react-native';
import { Card } from '../components/common/Card';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { ScreenBackground } from '../components/layout/ScreenBackground';
import { useAuth } from '../hooks/useAuth';
import { useDeviceType } from '../hooks/useDeviceType';
import {
  COLORS,
  FONT_SIZES,
  MOBILE_GUTTER,
  SCREEN_MAX_WIDTH,
  SPACING,
  TABLET_GUTTER,
} from '../lib/constants';

const REQUIRED_ENV_VARS = [
  'EXPO_PUBLIC_SUPABASE_URL',
  'EXPO_PUBLIC_SUPABASE_ANON_KEY',
];

export default function SignInScreen() {
  const router = useRouter();
  const isTablet = useDeviceType() === 'tablet';
  const { signIn, signOut, isLoading, isConfigured, setupError, session } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSignIn() {
    if (!email.trim() || !password) {
      Alert.alert('Champs requis', 'Ajoute un email et un mot de passe.');
      return;
    }

    try {
      setIsSubmitting(true);
      const { error } = await signIn(email.trim(), password);
      if (error) {
        Alert.alert('Connexion impossible', error.message);
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.keyboardView}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScreenBackground />
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          isTablet ? styles.scrollContentTablet : styles.scrollContentPhone,
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={[styles.page, isTablet ? styles.pageTablet : styles.pagePhone]}>
          <Card style={[styles.heroPanel, isTablet && styles.heroPanelTablet]} padding="xl">
            <View style={styles.brandBadge}>
              <LockKey size={18} color={COLORS.textInverse} weight="regular" />
            </View>
            <Text style={styles.kicker}>CIZO PRO</Text>
            <Text style={styles.title}>Un studio qui tient debout sur iPhone comme sur iPad.</Text>
            <Text style={styles.subtitle}>
              Le shell a ete reconstruit pour mettre la lecture du studio en premier:
              agenda, CRM et pilotage parlent enfin la meme langue.
            </Text>
            <View style={styles.bulletList}>
              <Text style={styles.bulletItem}>Agenda lisible en moins de trois secondes</Text>
              <Text style={styles.bulletItem}>CRM oriente valeur, recence et relance</Text>
              <Text style={styles.bulletItem}>Shell iPad plus mature, plus aerien, plus utile</Text>
            </View>
          </Card>

          <Card style={styles.formPanel} padding="xl">
            <Text style={styles.panelTitle}>
              {!isConfigured ? 'Mode demo' : setupError ? 'Compte incomplet' : 'Connexion'}
            </Text>
            <Text style={styles.panelBody}>
              {!isConfigured
                ? "Le backend n'est pas configure. L'application bascule automatiquement en mode demo pour que l'UI reste toujours visible."
                : setupError
                  ? setupError
                  : 'Connecte-toi pour charger les donnees live du salon.'}
            </Text>

            {!isConfigured ? (
              <>
                <View style={styles.envList}>
                  {REQUIRED_ENV_VARS.map((envVar) => (
                    <View key={envVar} style={styles.envRow}>
                      <WarningCircle size={16} color={COLORS.delayText} weight="fill" />
                      <Text style={styles.envVar}>{envVar}</Text>
                    </View>
                  ))}
                </View>
                <Button
                  title="Entrer dans la demo"
                  fullWidth
                  onPress={() => router.replace('/(tabs)/agenda')}
                />
              </>
            ) : setupError ? (
              <>
                {session ? (
                  <Button
                    title="Se deconnecter"
                    variant="secondary"
                    fullWidth
                    onPress={() => {
                      void signOut();
                    }}
                  />
                ) : null}
              </>
            ) : (
              <View style={styles.form}>
                <Input
                  label="Email"
                  value={email}
                  onChangeText={setEmail}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="email-address"
                  textContentType="username"
                  placeholder="manager@tonsalon.fr"
                />
                <Input
                  label="Mot de passe"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  textContentType="password"
                  placeholder="••••••••"
                />
                <Button
                  title="Se connecter"
                  fullWidth
                  onPress={() => {
                    void handleSignIn();
                  }}
                  disabled={isLoading}
                  loading={isSubmitting}
                />
              </View>
            )}
          </Card>
        </View>
      </ScrollView>

      {isLoading ? (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="small" color={COLORS.textPrimary} />
        </View>
      ) : null}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  keyboardView: {
    flex: 1,
    backgroundColor: COLORS.canvas,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  scrollContentPhone: {
    paddingHorizontal: MOBILE_GUTTER,
    paddingVertical: SPACING['4xl'],
  },
  scrollContentTablet: {
    paddingHorizontal: TABLET_GUTTER,
    paddingVertical: SPACING['4xl'],
  },
  page: {
    width: '100%',
    maxWidth: SCREEN_MAX_WIDTH,
    alignSelf: 'center',
    gap: SPACING.base,
  },
  pagePhone: {
    gap: SPACING.base,
  },
  pageTablet: {
    flexDirection: 'row',
    gap: SPACING.base,
  },
  heroPanel: {
    gap: SPACING.base,
    backgroundColor: COLORS.brandPrimary,
    borderColor: COLORS.brandPrimary,
  },
  heroPanelTablet: {
    flex: 1.2,
    minHeight: 520,
  },
  brandBadge: {
    width: 52,
    height: 52,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.brandAccent,
  },
  kicker: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.caption,
    color: 'rgba(255,255,255,0.72)',
    letterSpacing: 1.4,
  },
  title: {
    fontFamily: 'Satoshi-Variable',
    fontSize: 36,
    lineHeight: 40,
    fontWeight: '600',
    color: COLORS.textInverse,
    letterSpacing: -0.9,
  },
  subtitle: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.body,
    lineHeight: 24,
    color: 'rgba(255,255,255,0.76)',
    maxWidth: 440,
  },
  bulletList: {
    gap: SPACING.sm,
    marginTop: SPACING.sm,
  },
  bulletItem: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.body,
    color: COLORS.textInverse,
  },
  formPanel: {
    gap: SPACING.base,
    flex: 1,
  },
  panelTitle: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.h1,
    fontWeight: '600',
    color: COLORS.textPrimary,
    letterSpacing: -0.45,
  },
  panelBody: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.body,
    lineHeight: 22,
    color: COLORS.textSecondary,
  },
  form: {
    gap: SPACING.base,
  },
  envList: {
    gap: SPACING.sm,
  },
  envRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  envVar: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.bodySmall,
    color: COLORS.textPrimary,
  },
  loadingOverlay: {
    position: 'absolute',
    right: SPACING.base,
    top: SPACING.base,
  },
});
