import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../lib/constants';
import { FONT_SIZES, SPACING } from '../lib/constants';
import { useAuthBootstrap } from '../hooks/useAuthBootstrap';
import { useAuth } from '../hooks/useAuth';

void SplashScreen.preventAutoHideAsync().catch(() => {
  // Ignore repeated splash registration in dev reloads.
});

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      retry: 2,
    },
  },
});

export default function RootLayout() {
  useAuthBootstrap();

  const [fontsLoaded, fontError] = useFonts({
    'Satoshi-Variable': require('../assets/fonts/Satoshi-Variable.ttf'),
  });
  const [fontLoadTimedOut, setFontLoadTimedOut] = useState(false);
  const router = useRouter();
  const segments = useSegments();
  const { session, isLoading: authLoading, setupError, isConfigured } = useAuth();

  useEffect(() => {
    const timeout = setTimeout(() => {
      setFontLoadTimedOut(true);
    }, 1500);

    return () => {
      clearTimeout(timeout);
    };
  }, []);

  const isAppReady = fontsLoaded || !!fontError || fontLoadTimedOut;
  const isOnSignIn = segments[0] === 'sign-in';
  const canAccessApp = (!isConfigured || !!session) && !setupError;
  const shouldHoldForRedirect =
    !authLoading &&
    ((canAccessApp && isOnSignIn) || (!canAccessApp && !isOnSignIn));

  useEffect(() => {
    if (fontsLoaded || fontError) {
      void SplashScreen.hideAsync().catch(() => {
        // Ignore splash hide race conditions in dev reloads.
      });
    }
  }, [fontsLoaded, fontError]);

  useEffect(() => {
    if (fontLoadTimedOut) {
      void SplashScreen.hideAsync().catch(() => {
        // Ignore splash hide race conditions in dev reloads.
      });
    }
  }, [fontLoadTimedOut]);

  useEffect(() => {
    if (!isAppReady || authLoading) return;

    if (canAccessApp && isOnSignIn) {
      router.replace('/(tabs)/agenda');
      return;
    }

    if (!canAccessApp && !isOnSignIn) {
      router.replace('/sign-in');
    }
  }, [authLoading, canAccessApp, isAppReady, isOnSignIn, router]);

  if (!isAppReady || authLoading || shouldHoldForRedirect) {
    return (
      <GestureHandlerRootView style={styles.root}>
        <QueryClientProvider client={queryClient}>
          <View style={styles.loadingScreen}>
            <ActivityIndicator size="small" color={COLORS.textPrimary} />
            <Text style={styles.loadingText}>Chargement de Cizo...</Text>
          </View>
          <StatusBar style="dark" />
        </QueryClientProvider>
      </GestureHandlerRootView>
    );
  }

  return (
    <GestureHandlerRootView style={styles.root}>
      <QueryClientProvider client={queryClient}>
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: COLORS.canvas },
          }}
        >
          <Stack.Screen name="sign-in" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen
            name="client/[id]"
            options={{ presentation: 'card' }}
          />
          <Stack.Screen
            name="kpis"
            options={{ presentation: 'card' }}
          />
          <Stack.Screen
            name="campaign"
            options={{ presentation: 'modal' }}
          />
          <Stack.Screen
            name="booking"
            options={{ headerShown: false }}
          />
        </Stack>
        <StatusBar style="dark" />
      </QueryClientProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: COLORS.canvas,
  },
  loadingScreen: {
    flex: 1,
    backgroundColor: COLORS.canvas,
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.base,
    paddingHorizontal: SPACING.xl,
  },
  loadingText: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.body,
    color: COLORS.textSecondary,
  },
});
