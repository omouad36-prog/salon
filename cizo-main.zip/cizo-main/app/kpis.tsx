import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ArrowLeft } from 'phosphor-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useDashboard } from '../hooks/useDashboard';
import { KPICard } from '../components/dashboard/KPICard';
import { Card } from '../components/common/Card';
import { ScreenBackground } from '../components/layout/ScreenBackground';
import {
  COLORS,
  FONT_SIZES,
  ICON_SIZES,
  MOBILE_GUTTER,
  SCREEN_MAX_WIDTH,
  SPACING,
  TABLET_GUTTER,
  TOUCH_TARGET,
} from '../lib/constants';
import { useDeviceType } from '../hooks/useDeviceType';
import type { DashboardKPI } from '../types/dashboard';

function KPISection({ title, items }: { title: string; items: DashboardKPI[] }) {
  return (
    <Card style={styles.sectionCard} padding="lg">
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.grid}>
        {items.map((kpi) => (
          <View key={kpi.label} style={styles.gridItem}>
            <KPICard
              label={kpi.label}
              value={kpi.value}
              trend={kpi.trend}
              trendDirection={kpi.trendDirection}
            />
          </View>
        ))}
      </View>
    </Card>
  );
}

export default function KPIsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const isTablet = useDeviceType() === 'tablet';
  const { kpiRevenue, kpiClients, kpiOperations, kpiEquipe } = useDashboard();

  return (
    <View style={styles.container}>
      <ScreenBackground />
      <View style={[styles.page, isTablet ? styles.pageTablet : styles.pagePhone]}>
        <View style={[styles.header, { paddingTop: insets.top + SPACING.sm }]}>
          <Pressable
            onPress={() => router.back()}
            style={styles.backButton}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel="Retour"
          >
            <ArrowLeft size={ICON_SIZES.nav} color={COLORS.textPrimary} />
          </Pressable>
          <View style={styles.headerCopy}>
            <Text style={styles.headerTitle}>Tous les KPIs</Text>
            <Text style={styles.headerSubtitle}>Vue exhaustive du studio et de l'equipe</Text>
          </View>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <KPISection title="Revenus" items={kpiRevenue} />
          <KPISection title="Clients" items={kpiClients} />
          <KPISection title="Operations" items={kpiOperations} />
          <KPISection title="Equipe" items={kpiEquipe} />
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.canvas,
  },
  page: {
    flex: 1,
    width: '100%',
    maxWidth: SCREEN_MAX_WIDTH,
    alignSelf: 'center',
  },
  pagePhone: {
    paddingHorizontal: MOBILE_GUTTER,
  },
  pageTablet: {
    paddingHorizontal: TABLET_GUTTER,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.base,
    paddingBottom: SPACING.lg,
  },
  backButton: {
    width: TOUCH_TARGET,
    height: TOUCH_TARGET,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.surfaceElevated,
    borderWidth: 1,
    borderColor: COLORS.borderDefault,
  },
  headerCopy: {
    flex: 1,
    gap: 4,
  },
  headerTitle: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.h1,
    fontWeight: '600',
    color: COLORS.textPrimary,
    letterSpacing: -0.45,
  },
  headerSubtitle: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.body,
    color: COLORS.textSecondary,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: SPACING['4xl'],
    gap: SPACING.base,
  },
  sectionCard: {
    gap: SPACING.base,
  },
  sectionTitle: {
    fontFamily: 'Satoshi-Variable',
    fontSize: FONT_SIZES.h2,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.base,
  },
  gridItem: {
    minWidth: 160,
    flexGrow: 1,
    flexBasis: '47%',
  },
});
